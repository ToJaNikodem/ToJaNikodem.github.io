<?php
require('index.php');
$mysqli = new mysqli("localhost", "root", "", "firma");
if ($mysqli->connect_errno) {
    echo "Nie udało się połączyć z bazą danych: " . $mysqli->connect_error;
    exit();
}
$imieToAlter = $_POST["nameToAlter"];
$nazwToAlter = $_POST["surnameToAlter"];
$imie = $_POST["name"];
$nazw = $_POST["surname"];
$email = $_POST["email"];
$tel = $_POST["tel"];

$qr = "UPDATE klienci SET imie = '$imie', nazwisko = '$nazw', email = '$email', telefon = '$tel' WHERE imie='$imieToAlter' AND nazwisko ='$nazwToAlter';";
$mysqli->query($qr);
$mysqli->close();
header('location: index.php');
?>