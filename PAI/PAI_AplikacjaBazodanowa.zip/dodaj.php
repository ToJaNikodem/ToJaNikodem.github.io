<?php
require('index.php');
$mysqli = new mysqli("localhost", "root", "", "firma");
if ($mysqli->connect_errno) {
    echo "Nie udało się połączyć z bazą danych: " . $mysqli->connect_error;
    exit();
}
$imie = $_POST["name"];
$nazw = $_POST["surname"];
$email = $_POST["email"];
$tel = $_POST["tel"];

$qr = "INSERT INTO klienci (imie, nazwisko, email, telefon) VALUES ('$imie', '$nazw', '$email', '$tel');";
$valid = $mysqli->query($qr);
$mysqli->close();
header('location: index.php');
?>