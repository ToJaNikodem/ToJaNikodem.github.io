<!DOCTYPE html>
<html lang="pl">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style.css">
	<title>Firma</title>
</head>

<body>
	<div id="popup">
		Operacja wykonana pomyślnie
	</div>
	<div id="main">
		<h1>Moja firma - Klienci</h1>
		<table>
			<tr>
				<th>ID</th>
				<th>Imię</th>
				<th>Nazwisko</th>
				<th>Email</th>
				<th>Telefon</th>
			</tr>
			<?php
			$mysqli = new mysqli("localhost", "root", "", "firma");
			if ($mysqli->connect_errno) {
				echo "Nie udało się połączyć z bazą danych: " . $mysqli->connect_error;
				exit();
			}
			$query = "SELECT * FROM klienci";
			$result = $mysqli->query($query);
			$i = 0;
			while ($row = $result->fetch_assoc()) {
				$i++;
				if($i % 2 == 0){
					echo "<tr class='two'>";
				}
				else{
					echo "<tr class='one'>";
				}
				echo "<td>" . $row["id"] . "</td>";
				echo "<td>" . $row["imie"] . "</td>";
				echo "<td>" . $row["nazwisko"] . "</td>";
				echo "<td>" . $row["email"] . "</td>";
				echo "<td>" . $row["telefon"] . "</td>";
				echo "</tr>";
			}
			$mysqli->close();
			?>
		</table>
		<div class="bottom">
			<h3>Dodawanie danych</h3><br>
			<form action="dodaj.php" method="post">
				<input type="text" name="name" class="input" placeholder="Imię" required>
				<input type="text" name="surname" class="input" placeholder="Nazwisko" required>
				<input type="text" name="email" class="input" placeholder="Adres email" required>
				<input type="tel" name="tel" class="input" placeholder="Telefon" required><br>
				<input type="submit" value="Dodaj" class="button">
			</form>
		</div>
		<div class="bottom">
			<h3>Aktualizacja danych</h3><br>
			<form action="aktualizacja.php" method="post">
				<p>Wprowadz imie i nazwisko pracownika, którego dane chcesz uaktualnić</p>
				<input type="text" name="nameToAlter" class="input" placeholder="Imię" required>
				<input type="text" name="surnameToAlter" class="input" placeholder="Nazwisko" required>
				<p>Podaj dane do aktualizacji</p>
				<input type="text" name="name" class="input" placeholder="Imię">
				<input type="text" name="surname" class="input" placeholder="Nazwisko">
				<input type="text" name="email" class="input" placeholder="Adres email">
				<input type="tel" name="tel" class="input" placeholder="Telefon"><br>
				<input type="submit" value="Modyfikuj" class="button">
			</form>
		</div>
		<div class="bottom">
			<h3>Usuwanie danych</h3><br>
			<form action="usun.php" method="post">
				<input type="text" name="name" class="input" placeholder="Imię" required>
				<input type="text" name="surname" class="input" placeholder="Nazwisko" required>
				<input type="submit" value="Usuń" class="button">
			</form>
		</div>
	</div>
</body>

</html>