<?php
require('index.php');
$mysqli = new mysqli("localhost", "root", "", "firma");
if ($mysqli->connect_errno) {
    echo "Nie udało się połączyć z bazą danych: " . $mysqli->connect_error;
    exit();
}
$imie = $_POST["name"];
$nazw = $_POST["surname"];

$qr = "DELETE FROM klienci WHERE imie='$imie' AND nazwisko='$nazw';";
$mysqli->query($qr);
$mysqli->close();
header('location: index.php');
?>