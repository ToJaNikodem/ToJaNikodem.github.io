<!DOCTYPE html>
<html lang="pl">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" type="text/css" href="style.css">
   <title>Baza</title>
</head>

<body>
   <?php
   $conn = new mysqli('localhost', 'root', '', 'firma');
   if ($conn->connect_error) {
      die("Błąd połączenia: " . $conn->connect_error);
   }

   ?>
   <div id="main">
      <div id="header">
         <h1>PROJEKT ZAPYTANIA DO BAZY DANYCH</h1>
      </div>
      <div id="left">
         <p>LISTA pracowników:</p>
            <?php
            $sql = "SELECT * FROM pracownicy_firma";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
               echo $row["Id"] . " " . $row["Imie"] . " " . $row["Nazwisko"] . "<br>";
            }
            ?>
      </div>
      <div id="right">
         <p>Wyświetl dane pojedynczego użytkownika, wynik zapytania będzie dopisany w pliku</p>
         <p>zapytania.txt:</p>
         <form action="baza.php" method="post">
            <label for="imie">Imie:</label>
            <input type="text" id="imie" name="imie"><br>
            <label for="naziwsko">Nazwisko:</label>
            <input type="text" id="nazwisko" name="nazwisko"><br>
            <input type="submit" value="przeslij" name="submit">
         </form>

         <p>Dane użytkownika:</p>

         <?php
         if (isset($_POST["imie"]) && isset($_POST["nazwisko"])) {
            $imie = $_POST["imie"];
            $nazw = $_POST["nazwisko"];
            $qr = "SELECT * FROM pracownicy_firma WHERE imie ='$imie'";
            $wynik1 = mysqli_query($conn, $qr);
            $wynik = mysqli_fetch_array($wynik1);
         }
         if (isset($wynik)) {
            echo $wynik['Id'] . " " . $wynik['Imie'] . " " . $wynik['Nazwisko'] . " " . $wynik['DataUrodzenia'] . " " . $wynik['Ulica'] . " " . $wynik['Miasto'] . " " . $wynik['Wojewodztwo'] . " " . $wynik['KodPocztowy'] . " " . $wynik['Email'] . " " . $wynik['DataPrzystapienia'];
         }

         $myfile = fopen("zapytania.txt", "a");
         if (isset($wynik)) {
            fwrite($myfile, $wynik['Id'] . " " . $wynik['Imie'] . " " . $wynik['Nazwisko'] . " " . $wynik['DataUrodzenia'] . " " . $wynik['Ulica'] . " " . $wynik['Miasto'] . " " . $wynik['Wojewodztwo'] . " " . $wynik['KodPocztowy'] . " " . $wynik['Email'] . " " . $wynik['DataPrzystapienia'] . "\n");
            fclose($myfile);
         }
         ?>

      </div>
      <div id="footer">

      </div>
   </div>

</body>

</html>