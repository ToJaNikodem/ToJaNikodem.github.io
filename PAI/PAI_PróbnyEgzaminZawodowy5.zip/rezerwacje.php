<!DOCTYPE html>
<html lang="pl">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="style.css">
   <title>KINO "Za rogiem"</title>
</head>

<body>
   <main>
      <header>
         <img src="baner.jpg" alt="baner">
      </header>
      <div class="left">
         <ul>
            <li><a href="index.html">Strona Główna</a></li>
         </ul>
         <hr>
         <form action="rezerwacje.php" method="post">
            <p>Data i godzina seansu</p>
            <input type="date" name="data">
            <input type="time" name="czas">
            <input type="submit">
         </form>
      </div>
      <div class="right">
         <?php
         $mysqli = new mysqli('localhost', 'root', '', 'kino');

         if (isset($_POST['data']) && isset($_POST['czas'])) {
            $data = $_POST['data'];
            $czas = $_POST['czas'];

            $qr = "SELECT Miejsce, Rzad FROM rezerwacje WHERE Data='$data' AND Godzina='$czas' GROUP BY Rzad ORDER BY Rzad ASC;";

            $result = $mysqli->query($qr);

            
            echo "EKRAN";
            echo "<table>";
            while ($row = $result->fetch_assoc()) {
               echo "<tr>";
               echo "<th>" . $row['Rzad'] . "</th>";
               for ($j = 1; $j <= 20; $j++) {
                  if ($row['Miejsce'] == $j){
                     echo "<td class='active'>$j</td>";
                  }else {
                     echo "<td class='inactive'>$j</td>";
                  }
               }
               echo "</tr>";
            }
            echo "</table>";
         } else {
            echo "Podaj poprawną datę i godzinę seansu";
         }
         ?>
      </div>
      <footer>
         <h5>Egzamin INF.03 - AUTOR: 00000000000</h5>
      </footer>
   </main>
</body>

</html>