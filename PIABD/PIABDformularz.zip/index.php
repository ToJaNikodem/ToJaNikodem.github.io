<!DOCTYPE html>
<html lang="pl">

<head>
	<meta charset='utf-8'>
	<title>Zapis do bazy</title>
	<link rel='Stylesheet' href='style.css'>
</head>

<body>
	<div id='baner'>
		<h2>ZSTU w TRZEBINI</h2>
	</div>
	<div id='lewy'>
		<h2>Dodaj sale</h2>
		<form action='index.php' method='POST'>
			<label>nr_sali</label><input type='text' name='nr_sali'></br>
			<label>rozm_sali:</label><input type='text' name='rozm'></br>
			<label>ekran:</label><input type='text' name='ekran'></br>
			<input type='submit' value='DODAJ'>
		</form>
		<?php
		$mysqli = new mysqli('localhost', 'root', '', 'klasa3c1');
		if (isset($_POST['nr_sali']) && isset($_POST['rozm']) && isset($_POST['ekran'])) {

			$nr_sali = $_POST['nr_sali'];
			$rozm_sali = $_POST['rozm'];
			$ekran = $_POST['ekran'];

			$qr = "INSERT INTO sale (nr_sali, rozm_sali, ekran) VALUES ('$nr_sali','$rozm_sali','$ekran')";

			$result = $mysqli->query($qr);

			echo "sala" . ' ' . $nr_sali . ' ' . "została dodany do bazy danych";
		}
		?>
	</div>
	<div id='prawy'>
		<h3>numer i rozmiar sal</h3>
		<ul>
			<?php
			$qr = "SELECT nr_sali, rozm_sali, ekran FROM sale";
			$result = $mysqli->query($qr);
			while ($row = $result->fetch_assoc()) {
				echo '<li>' . $row['nr_sali'] . ' ' . $row['rozm_sali'] . ' ' . $row['ekran'] . ' ' . '</li>';
			};
			?>
		</ul>
	</div>
	<div id="lewy2">
		<form action='index.php' method="POST">
			<select name="lista2" id="">
				<option value="T">T</option>
				<option value="N">N</option>
			</select>
			<button type="submit" name="typy">Typy przedmiotow </button>
		</form>
	</div>
	<div id="prawy2">
		<h3>numery Sal </h3>
		<ul>
			<?php
			if (isset($_POST['lista2'])) {
				$ekran = $_POST['lista2'];
				echo $ekran;
				echo '</br>';
				echo '</br>';
				$qr = "SELECT nr_sali, rozm_sali, ekran FROM sale WHERE ekran='$ekran'";
				$result = $mysqli->query($qr);
				while ($row = $result->fetch_assoc()) {
					echo '<li>' . $row['nr_sali'] . ' ' . $row['rozm_sali'] . ' ' . $row['ekran'] . ' ' . '</li>';
				};
			}
			?>
		</ul>
	</div>
	<div id="lewy3">
		<form action='index.php' method="POST">
			<select name="lista3" id="">
				<option value="ARCHITEKTURA KOMPUTEROW">AK</option>
				<option value="BAZY DANYCH">BD</option>
				<option value="MODELOWANIE CYFROWE">MC</option>
				<option value="PODSTAWY INFORMATYKI">PI</option>
				<option value="METODY NUMERYCZNE">MN</option>
				<option value="ORACLE">DBO</option>
			</select>
			<button type="submit" name="typy">Typy przedmiotow </button>
		</form>
	</div>
	<div id="prawy3">
		<h3>Oceny AVG</h3>
		<ul>
			<?php
			if(isset($_POST['lista3'])) {

				$przedmiot = $_POST['lista3'];
				echo '</br>';
				echo '</br>';
				$qr = "SELECT s.NAZWISKO AS nazwisko, p.NAZWA_PRZEDM AS przedm, AVG(o.OCENA) AS avg FROM studenci s, oceny o, przedmioty p WHERE s.NR_STUD=o.NR_STUD AND o.NR_PRZEDM=p.NR_PRZEDM  AND p.NAZWA_PRZEDM='$przedmiot' GROUP BY s.NAZWISKO";
				$result = $mysqli->query($qr);
				while ($row = $result->fetch_assoc()) {
					echo '<li>' . $row['nazwisko'] . ' ' . $row['przedm'] . ' ' . $row['avg'] . ' ' . '</li>';
				};
			}
			$mysqli->close();
			?>
		</ul>
	</div>
	<div id='stopka'>
		<p>Projekt witryny: ZSTU 2023</p>
	</div>
</body>

</html>