const photo = document.querySelectorAll(".mini");
    console.log(photo[0]);
const name = document.querySelector(".nameCar");
console.log(name);
const changer = document.querySelector(".change");

photo[0].addEventListener("click", () => {
    changer.src =  "captur.png";
    name.innerHTML = "Renault Captur";
})

photo[1].addEventListener("click", () => {
    changer.src =  "leon.png";
    name.innerHTML = "Seat Leon";
})

photo[2].addEventListener("click", () => {
    changer.src =  "octavia.png";
    name.innerHTML = "Skoda Octavia";
})

photo[3].addEventListener("click", () => {
    changer.src =  "trafic.png";
    name.innerHTML = "Trafic car";
})



