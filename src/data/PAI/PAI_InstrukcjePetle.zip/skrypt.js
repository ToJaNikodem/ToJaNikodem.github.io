//zad 1
var str = "";
for (var i = 2; i <= 100; i += 2) {
	str += i;
	str += " ";
}
str += "<br><br>";
var dataDiv = document.getElementById("dataDiv");

//zad 2
var i = 1;
while (i <= 10) {
	str += "Ten napis się powtarza...<br>";
	i++;
}

//zad3
str += "<br><hr>";
var i = 0;
while (i < 3) {
	var j = 0;
	while (j < 3) {
		str += i + " " + j;
		str += "<br>";
		j++;
	}
	str += "<hr>";
	i++;
}
str += "<br>";

//zad4
var i = 0;
while (true) {
	str += "Wartość zmiennej i to " + i + "<br>";
	i++;
	if (i > +9) {
		break;
	}
}
str += "<br>";

//ćw 5.1
i = 0;
while (i++ < 10) {
	str += "Ten napis się powtarza...";
	str += "<br>";
}
str += "<br>";

//ćw 5.2a
str += "<hr>";
i = 0;
while (i < 3) {
	j = 0;
	while (j < 3) {
		str += i + " " + j;
		j++;
		str += "<br>";
	}
	i++;
	str += "<hr>";
}
str += "<br>";

//ćw 5.2b
str += "<hr>";
i = 0;
while (i++ < 3) {
	j = 0;
	while (j++ < 3) {
		str += i - 1 + " " + (j - 1);
		str += "<br>";
	}
	str += "<hr>";
}
str += "<br>";

//ćw 5.3
for (i = 1; i <= 20; i++) {
	if (i % 2 == 0) {
		str += i;
		str += " ";
	}
}
str += "<br><br>";

//ćw 5.4
i = 10;
while (i <= 30) {
	if (i % 2 != 0 && i != 15 && i != 21 && i != 27) {
		str += i;
		str += " ";
	}
	i++;
}
str += "<br><br>";

//ćw 5.5
for (i = 0;; i++) {
	if (i>=10) break; 
	str += "Ten napis się powtarza...";
	str += "<br />";
}

dataDiv.innerHTML = str;
