<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl2.css">
    <title>Wynajem pokoi</title>
</head>

<body>
    <header>
        <h1>Pensjonat pod dobrym humorem</h1>
    </header>
    <section id="left">
        <a href="index.html">GŁÓWNA</a>
        <img src="1.jpg" alt="pokoje">
    </section>
    <section id="center">
        <a href="cennik.php">CENNIK</a>
        <table>
            <?php
            $mysqli = new mysqli('localhost', 'root', '', 'wynajem');

            $qr = 'SELECT * FROM pokoje;';
            $result = $mysqli->query($qr);

            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row['id'] . "</td><td>" . $row['nazwa'] . "</td><td>" . $row['cena'] . "</td></tr>";
            }

            $mysqli->close();
            ?>
        </table>
    </section>
    <section id="right">
        <a href="kalkulator.html">KALKULATOR</a>
        <img src="3.jpg" alt="pokoje">
    </section>
    <footer>
        <p>Stronę opracował: 00000000000</p>
    </footer>
</body>

</html>