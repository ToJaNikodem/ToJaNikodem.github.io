<!DOCTYPE html>
<html lang="pl">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="styl3.css">
	<title>Zawody wędkarskie</title>
</head>

<body>
	<div id="left">
		<h1>Zawody polskich wędkarzy</h1>
	</div>
	<div id="right">
		<img src="zawody.jpg" alt="zawody wędkarskie">
	</div>
	<main>
		<h2>Łowiska</h2>
		<ol>
			<li>Zalew wędkarski</li>
			<li>Zbiornik bukówka</li>
			<li>Jezioro bartbetowskie</li>
			<li>Warta-Obrzycka</li>
		</ol>
		<h2>Dodaj nowe zawody wędkarskie</h2>
		<form action="zgloszenie.php" method="POST">
			<label for="lowiskoID">Łowisko: <br><input type="number" name="lowisko" id="lowiskoID"></label><br>
			<label for="dataID">Data: <br><input type="date" name="data" id="dataID"></label><br>
			<label for="sedziaID">Sędzia: <br><input type="text" name="sedzia" id="sedziaID"></label><br>
			<br>
			<input type="reset" value="CZYŚĆ">
			<input type="submit" value="DODAJ">
		</form>
	</main>

	<div class="footer">
		<a href="kwerendy.txt" download="kwerendy.txt">Pobierz</a>
	</div>
	<div class="footer">
		<p>Stronę przygotował: 00000000000</p>
	</div>

</body>

</html>