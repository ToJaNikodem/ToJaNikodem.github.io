<!DOCTYPE html>
<html lang="pl">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="style.css">
   <title>KINO "Za rogiem"</title>
</head>

<body>
   <main>
      <header>
         <img src="baner.jpg" alt="baner">
      </header>
      <div class="left">
         <ul>
            <li><a href="index.html">Strona Główna</a></li>
         </ul>
         <hr>
         <form action="rezerwacje.php" method="post">
            <p>Data i godzina seansu</p>
            <input type="date" name="data">
            <input type="time" name="czas">
            <input type="submit">
         </form>
      </div>
      <div class="right">
         <?php
         $mysqli = new mysqli('localhost', 'root', '', 'kino');
         $mysqli->set_charset("utf8");

         if (isset($_POST['data']) && isset($_POST['czas'])) {
            $data = $_POST['data'];
            $godzina = $_POST['czas'];

            echo "EKRAN <br><br>";

            echo "<table>";
            for ($r = 1; $r <= 15; $r++) {
               echo "<tr>";
               echo "<th>$r</th>";
               for ($m = 1; $m <= 20; $m++) {
                  $qr = "SELECT * FROM rezerwacje WHERE data='$data' AND godzina='$godzina' AND rzad='$r' AND miejsce='$m'";
                  $result = $mysqli->query($qr);
                  if ($result->num_rows > 0) {
                     echo "<td class='active'>$m</td>";
                  } else {
                     echo "<td class='inactive'>$m</td>";
                  }
               }
               echo "</tr>";
            }
            echo "</table>";
         }
         ?>
      </div>
      <footer>
         <h5>Egzamin INF.03 - AUTOR: 00000000000</h5>
      </footer>
   </main>
</body>

</html>