<!DOCTYPE html>
<html lang="pl">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="styl_1.css">
   <title>Wędkowanie</title>
</head>

<body>
   <div id="banner">
      <h1>Portal dla wedkarzy</h1>
   </div>
   <div id="left">
      <div id="leftUp">
         <h3>Ryby zamieszkujące rzeki</h3>
         <ol>
            <?php
            $mysqli = new mysqli("localhost", "root", "", "wedkowanie");
            if ($mysqli->connect_errno) {
               echo "Nie udało się połączyć z bazą danych: " . $mysqli->connect_error;
               exit();
            }
            $qr = "SELECT r.nazwa AS nazwa, l.akwen AS akwen, l.wojewodztwo AS wojewodztwo FROM ryby r INNER JOIN lowisko l ON r.id=l.ryby_id WHERE l.rodzaj = 3;";

            $result = $mysqli->query($qr);
            while ($row = $result->fetch_assoc()) {
               echo "<li>" . $row['nazwa'] . " pływa w rzece " . $row['akwen'] . ", " . $row['wojewodztwo'] . "</li>";
            }

            ?>
         </ol>
      </div>
      <div id="leftDown">
         <h3>Ryby drapieżne naszych wód</h3>
         <table>
            <tr>
               <th>L.p.</th>
               <th>Gatunek</th>
               <th>Występowanie</th>
            </tr>
            <?php
            $qr = "SELECT id, nazwa, wystepowanie FROM ryby WHERE styl_zycia=1;";

            $result = $mysqli->query($qr);
            while ($row = $result->fetch_assoc()) {
               echo "<tr><td>" . $row['id'] . "</td><td>" . $row['nazwa'] . "</td><td>" . $row['wystepowanie'] . "</td></tr>";
            }
            $mysqli->close();
            ?>
         </table>
      </div>
   </div>
   <div id="right">
      <img src="ryba1.jpg" alt="Sum">
      <br>
      <a href="kwerendy.txt" download>Pobierz kwerendy</a>
   </div>
   <div id="footer">
      <p>Stronę wykonał: 00000000000</p>
   </div>
</body>

</html>