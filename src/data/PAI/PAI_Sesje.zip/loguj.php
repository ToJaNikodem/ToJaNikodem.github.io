<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autoryzacja danych</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div id="box">
        <form action="loguj.php" method="post">

            <h1><b>Logowanie</b></h1><br>
            <b>Nazwa użytkownika:</b><br>
            <input type=text name="nazwa" value="" size="25"><br><br>
            <b>Hasło:</b><br>
            <input type=password name="haslo" value="" size="25"><br><br>
            <input type="submit" value="Zaloguj się"><br>
            <?php
            session_start();
            if (isset($_SESSION['log'])) {
                header('location: strona.php');
                exit();
            } else if (isset($_POST['nazwa']) && isset($_POST['haslo'])) {
                $login = $_POST['nazwa'];
                $password = $_POST['haslo'];
                if (($login == 'user1' && $password == '123456')||($login == 'user2' && $password == '654321')||($login == 'admin' && $password == '135246')) {
                    $_SESSION['log'] = 'nazwa';
                    header('location: strona.php');
                    exit;
                } else {
                    echo "Nieprawidłowe dane logowania";
                }
            }
            ?>
        </form>
    </div>

</body>

</html>