import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HashMap<String, Integer> namesMap = new HashMap<String, Integer>();
        
        while (true) {
            System.out.print("Podaj imię (wprowadź '-' aby zakończyć): ");
            String name = scanner.nextLine();
            if (name.equals("-")) {
                break;
            }
            if (namesMap.containsKey(name)) {
                namesMap.put(name, namesMap.get(name) + 1);
            } else {
                namesMap.put(name, 1);
            }
        }
        System.out.println("Liczba wystąpień poszczególnych imion:");
        for (String name : namesMap.keySet()) {
            int count = namesMap.get(name);
            System.out.println(name + ": " + count);
        }
    }
}