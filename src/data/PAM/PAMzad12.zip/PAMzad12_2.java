import java.util.HashMap;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        HashMap<String, String> pary = new HashMap<String, String>();
        Scanner scanner = new Scanner(System.in);

        String imie1, imie2;
        do {
            System.out.print("Podaj imię pierwszej osoby (wpisz '-' aby zakończyć): ");
            imie1 = scanner.nextLine();
            if (!imie1.equals("-")) {
                System.out.print("Podaj imię drugiej osoby: ");
                imie2 = scanner.nextLine();
                pary.put(imie1, imie2);
            }
        } while (!imie1.equals("-"));

        System.out.print("Podaj imię osoby, dla której chcesz poznać partnera: ");
        String imie = scanner.nextLine();
        if (pary.containsKey(imie)) {
            System.out.println("Partner " + imie + " to " + pary.get(imie));
        } else {
            System.out.println("Nie znaleziono partnera dla osoby o imieniu " + imie);
        }
    }
}