#include <fstream>
#include <iostream>
#include <string>

using namespace std;

int main() {
   ifstream slowa, nowe;
   nowe.open("nowe.txt");
   slowa.open("slowa.txt");
   if (!nowe.good() || !slowa.good()) {
      cout << "Bład dostępu do plików" << endl;
   } else {
      slowa.close();
      string noweSlowo = "";
      int ileRazy = 0;
      while (!nowe.eof()) {
         nowe >> noweSlowo;
         ileRazy = 0;

         slowa.open("slowa.txt");
         string slowo = "";
         while (!slowa.eof()) {
            slowa >> slowo;
            if (slowo == noweSlowo)
               ileRazy++;
         }
         slowa.close();
         cout << noweSlowo << " " << ileRazy << endl;
      }
      nowe.close();
   }

   return 0;
}